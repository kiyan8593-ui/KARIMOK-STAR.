import './style.css';

document.querySelector('#app').innerHTML = `
<header>
<h1>KARIMOK <span>STAR</span></h1>
<p>استودیوی حرفه‌ای تدوین ویدیو</p>
</header>
<main>
<section class="preview">
<div id="previewText">پیش‌نمایش ویدیو</div>
<video id="video" controls></video>
</section>
<section class="panel">
<h3>انتخاب ویدیو یا عکس</h3>
<input type="file" id="file" accept="video/*,image/*">
</section>
<section class="panel">
<h3>افکت‌های تصویری</h3>
<div class="tools">
<button data-effect="zoom">زوم</button>
<button data-effect="gray">سیاه و سفید</button>
<button data-effect="blur">Motion Blur آزمایشی</button>
<button data-effect="bright">روشنایی</button>
<button data-effect="reset">بازنشانی</button>
</div>
</section>
<section class="panel">
<h3>موسیقی</h3>
<input type="file" id="music" accept="audio/*">
<audio id="audio" controls></audio>
</section>
<section class="panel">
<h3>تنظیمات تصویر</h3>
<label>شدت افکت</label>
<input type="range" id="intensity" min="1" max="20" value="5">
<button id="export">آماده‌سازی خروجی</button>
<p id="status"></p>
</section>
</main>
`;

const video = document.querySelector('#video');
const file = document.querySelector('#file');
let selectedEffect = 'reset';

file.addEventListener('change', () => {
const selected = file.files[0];
if (!selected) return;
video.src = URL.createObjectURL(selected);
video.style.display = 'block';
document.querySelector('#previewText').style.display = 'none';
});

document.querySelector('#music').addEventListener('change', e => {
if (e.target.files[0]) {
document.querySelector('#audio').src =
URL.createObjectURL(e.target.files[0]);
}
});

function applyEffect() {
const amount = Number(document.querySelector('#intensity').value);
video.style.filter = 'none';
video.style.transform = 'none';

if (selectedEffect === 'zoom') {
video.style.transform = `scale(${1 + amount / 20})`;
}
if (selectedEffect === 'gray') {
video.style.filter = 'grayscale(1)';
}
if (selectedEffect === 'blur') {
video.style.filter = `blur(${amount / 5}px)`;
}
if (selectedEffect === 'bright') {
video.style.filter = `brightness(${1 + amount / 20})`;
}
}

document.querySelectorAll('[data-effect]').forEach(button => {
button.addEventListener('click', () => {
selectedEffect = button.dataset.effect;
applyEffect();
});
});

document.querySelector('#intensity').addEventListener('input', applyEffect);

document.querySelector('#export').addEventListener('click', () => {
document.querySelector('#status').textContent =
'این نسخه پیش‌نمایش است؛ موتور خروجی MP4 هنوز اضافه نشده است.';
});
