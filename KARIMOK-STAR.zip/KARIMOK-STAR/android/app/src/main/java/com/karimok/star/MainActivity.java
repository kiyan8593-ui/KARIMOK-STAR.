package com.karimok.star;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
